package com.example.imguruploader.service;

import com.example.imguruploader.model.User;
import com.example.imguruploader.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceTests {

    private final UserRepository userRepository = mock(UserRepository.class);
    private final UserService userService = new UserService();

    @Test
    void registerUser_ShouldSaveUser() {
        User user = new User();
        user.setUsername("testuser");
        user.setPassword("password");

        when(userRepository.save(Mockito.any(User.class))).thenReturn(user);

        User savedUser = userService.registerUser("testuser", "password");

        assertNotNull(savedUser);
        assertEquals("testuser", savedUser.getUsername());
    }

    @Test
    void authenticateUser_ShouldReturnUserWhenValidCredentials() {
        User user = new User();
        user.setUsername("testuser");
        user.setPassword("password");

        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));

        Optional<User> authenticatedUser = userService.authenticateUser("testuser", "password");

        assertTrue(authenticatedUser.isPresent());
        assertEquals("testuser", authenticatedUser.get().getUsername());
    }

    @Test
    void authenticateUser_ShouldReturnEmptyWhenInvalidCredentials() {
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.empty());

        Optional<User> authenticatedUser = userService.authenticateUser("testuser", "wrongpassword");

        assertFalse(authenticatedUser.isPresent());
    }
}
