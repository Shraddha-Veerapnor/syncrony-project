package com.example.imguruploader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImgurUploaderApplication {
    public static void main(String[] args) {
        SpringApplication.run(ImgurUploaderApplication.class, args);
    }
}