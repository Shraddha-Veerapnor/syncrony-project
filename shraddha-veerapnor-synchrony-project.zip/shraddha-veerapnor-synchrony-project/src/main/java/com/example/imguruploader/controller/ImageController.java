package com.example.imguruploader.controller;

import com.example.imguruploader.model.Image;
import com.example.imguruploader.model.User;
import com.example.imguruploader.service.ImageService;
import com.example.imguruploader.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/images")
public class ImageController {

    @Autowired
    private ImageService imageService;

    @Autowired
    private UserService userService;

    @PostMapping("/upload")
    public ResponseEntity<String> uploadImage(@RequestParam String username, @RequestParam String password, @RequestParam String link) {
        return userService.authenticateUser(username, password)
                .map(user -> {
                    Image image = imageService.uploadImage(user, link);
                    return ResponseEntity.ok("Image uploaded: " + image.getLink());
                })
                .orElse(ResponseEntity.status(401).body("Authentication failed."));
    }
}