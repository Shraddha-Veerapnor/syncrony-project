package com.example.imguruploader.service;

import com.example.imguruploader.model.Image;
import com.example.imguruploader.model.User;
import org.springframework.stereotype.Service;

@Service
public class ImageService {

    public Image uploadImage(User user, String link) {
        Image image = new Image();
        image.setUser(user);
        image.setLink(link);
        user.getImages().add(image);
        return image;
    }
}