package com.example.imguruploader.controller;

import com.example.imguruploader.model.User;
import com.example.imguruploader.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<User> registerUser(@RequestParam String username, @RequestParam String password) {
        User user = userService.registerUser(username, password);
        return ResponseEntity.ok(user);
    }

    @PostMapping("/authenticate")
    public ResponseEntity<String> authenticateUser(@RequestParam String username, @RequestParam String password) {
        return userService.authenticateUser(username, password)
                .map(user -> ResponseEntity.ok("Authentication successful!"))
                .orElse(ResponseEntity.status(401).body("Authentication failed."));
    }
}
